<script>


export default {
  data () {
      return {
        }
     },
   mounted () {
     
  
        this.$router.push('login')
         localStorage.clear();
        
    

    },

}
</script>