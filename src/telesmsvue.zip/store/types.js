export const Tologin = 'tologin';
export const SetCurrentView = 'setCurrentView';